import csv
import numpy as np
import matplotlib.pyplot as plt


# 阶乘
def factorial(n):
    if n == 1:
        return n
    else:
        return n * factorial(n - 1)


# 求平均值
def avr_val(p, x):
    avr = 0
    for i in range(len(x)):
        avr += p[i] * x[i]
    return avr


# 泊松分布
def poisson(a, x):
    y = a ** x / factorial(x) * np.exp(-a)
    return y


x = []
y = []
with open('Poisson_data1.csv', 'r') as f:
    reader = csv.reader(f)
    for row in reader:
        x.append(int(float(row[0])))
        y.append(float(row[1]))

x, y = np.array(x), np.array(y)
p = y / sum(y)  # 计算概率

avr = avr_val(p, x)
x0 = [i for i in range(1, len(x))]
y0 = [poisson(avr, i) for i in x0]

plt.figure()
plt.plot(x0, y0, 'red')
plt.scatter(x, p)
plt.show()


'''
---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------
'''
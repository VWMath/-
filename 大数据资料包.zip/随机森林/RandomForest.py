import csv
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
# ↓与决策树交叉验证做对比用，可以忽略
import matplotlib.pyplot as plt
from sklearn import tree
from sklearn.model_selection import cross_val_score

data = []
label = []
with open('digits.csv', 'r') as f:
    reader = csv.reader(f)
    n = 0
    for row in reader:
        if n == 0:
            n += 1
            continue
        r = [float(i) for i in row[0:-1]]
        data.append(r)
        label.append(row[-1])

label_name = {}
n = 0
for item in label:
    if item not in label_name:
        label_name[item] = n
        n += 1

label = [label_name[item] for item in label]

xtr, xte, ytr, yte = train_test_split(data, label, test_size=0.3, random_state=1)

rfc = RandomForestClassifier(random_state=3, n_estimators=100)  # n_estimators为决策树数量，random_state，n_estimators均可不填
rfc.fit(xtr, ytr)

# 用skl自带的函数预测并返回准确度
score = rfc.score(xte, yte)
print('准确度为：%f%%' % (score * 100))
# 自己写
# ypr = rfc.predict(xte)
# acc = sum(np.array(ypr) == np.array(yte)) / len(ypr)
# print('准确度为：%f%%' % (acc * 100))

# ------------------------
# 绘制随机森林和决策树在一组交叉验证下的效果对比
rfc = RandomForestClassifier(random_state=3, n_estimators=100)
clf = tree.DecisionTreeClassifier(random_state=3)

n = 20
rfc_s = cross_val_score(rfc, data, label, cv=n, scoring='accuracy')  # cv为迭代次数
clf_s = cross_val_score(clf, data, label, cv=n, scoring='accuracy')

plt.plot(range(1, n + 1), rfc_s, label='RandomForest')
plt.plot(range(1, n + 1), clf_s, label='DecisionTree')
plt.legend()
plt.ylabel('accuracy')
plt.xlabel('n')
plt.show()


'''
---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------
'''
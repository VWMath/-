---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------

数据集：
注：不同数据集的处理方式可能有所不同，建议使用前先观察数据集格式

-----分类，聚类问题-----
多分类
    iris                                鸢尾花
    wine                                葡萄酒
    digits                              手写数字
    Multi-classification_data1          生成数据集
    Multi-classification_data2          生成数据集(该样本质量较差)
    Multi-classification_data3          生成数据集
    !!!以下两个数据集较大，酌情选择！！！
    covtype                             森林植被
    kddcup99                            入侵检测
二分类
    breast_cancer                       乳腺癌
    classification_data1                生成数据集
    classification_data2                生成数据集
    classification_data3                生成数据集


-----回归问题-----
一元回归
    简单线性回归
    data_linear_regression1             自制数据集
    data_linear_regression2             自制数据集
    data_linear_regression3             自制数据集
    data_linear_regression4             自制数据集
    data_linear_regression5             自制数据集
    泊松回归
    Poisson_data1                       自制训练集
    Poisson_data2                       自制训练集
    Poisson_data3                       自制训练集
多元回归
    house_california                    房价预测
    diabetes                            糖尿病
    data_Multiple_linear_regression1    自制数据集
    data_Multiple_linear_regression2    自制数据集
    data_Multiple_linear_regression3    自制数据集

---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------
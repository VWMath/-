import csv
import numpy as np
import matplotlib.pyplot as plt
from sklearn import tree
from sklearn.model_selection import train_test_split

data = []
label = []
# 读取数据
with open('wine.csv', 'r') as f:
    reader = csv.reader(f)
    n = 0
    for row in reader:
        if n == 0:
            n += 1
            continue
        r = [float(item) for item in row[0:-1]]
        data.append(r)
        label.append(row[-1])

# 将标签转化为0，1，2...的形式
label_name = {}
n = 0
for item in label:
    if item not in label_name:
        label_name[item] = n
        n += 1

class_names = label  # 画决策树时要用，可以不管
label = [label_name[item] for item in label]

xtr, xte, ytr, yte = train_test_split(data, label, test_size=0.3, random_state=3)
clf = tree.DecisionTreeClassifier(random_state=3)  # 创建决策树分类器
clf.fit(xtr, ytr)  # 拟合
# 用skl自带的函数预测并返回准确度
score = clf.score(xte, yte)
print('准确度为：%f%%' % (score * 100))

# 自己写
# ypr = clf.predict(xte)
# acc = sum(np.array(ypr) == np.array(yte)) / len(ypr)
# print('准确度为：%f%%' % (acc * 100))

# ------------------------
# 绘制决策树
feature_name = []
with open('wine.csv', 'r') as f:
    reader = csv.reader(f)
    for row in reader:
        feature_name = (row[0:-1])
        break

tree.plot_tree(clf, feature_names=feature_name, class_names=class_names, filled=True, rounded=True)
plt.show()


'''
---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------
'''
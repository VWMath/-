import csv
import numpy as np
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

X = []
Y = []
with open('data_Multiple_linear_regression1.csv', 'r') as f:
    reader = csv.reader(f)
    n = 0
    for row in reader:
        if n == 0:
            n += 1
            continue
        r = [float(i) for i in row[0:-1]]
        X.append(r)
        Y.append(float(row[-1]))

model = LinearRegression()
model.fit(X, Y)

# ------------------------
# 绘制三维图像
n = np.linspace(-10, 100, 2)
N = [[i, i] for i in n]
Ypr = model.predict(N)

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

x1 = [i[0] for i in X]
x2 = [i[1] for i in X]

ax.plot(n, n, Ypr, 'red')
ax.scatter(x1, x2, Y)
plt.show()


'''
---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------
'''
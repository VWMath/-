import numpy as np
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

X, Y = datasets.make_moons(n_samples=500, noise=0.3, random_state=42)
X_x = []
for i in X:
    X_x.append(i[0])

X_y = X[:, 1]
X_x0, X_x1, X_y0, X_y1 = [], [], [], []

for i in range(len(Y)):
    if Y[i]:
        X_x1.append(X_x[i])
        X_y1.append(X_y[i])
    else:
        X_x0.append(X_x[i])
        X_y0.append(X_y[i])

Xtr, Xte, Ytr, Yte = train_test_split(X, Y, random_state=1, test_size=0.3)

log_clf = LogisticRegression()
log_clf.fit(Xtr, Ytr)
Plog = log_clf.predict(Xte)
print(log_clf.score(Xte, Yte))
De_clf = DecisionTreeClassifier(random_state=2)
De_clf.fit(Xtr, Ytr)
PDe = De_clf.predict(Xte)
print(De_clf.score(Xte, Yte))
svm_clf = SVC()
svm_clf.fit(Xtr, Ytr)
Psvm = svm_clf.predict(Xte)
print(svm_clf.score(Xte,Yte))
Yp = np.array((Plog + PDe + Psvm) >= 2, dtype='int')
print(accuracy_score(Yte, Yp))

'''
---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------
'''
import csv
import numpy as np
import math
from random import random
from sklearn.model_selection import train_test_split
from sklearn import svm

'''
------------------------------------------
最复杂的一个，老师教的肯定不是这个(T_T)
不想写注释了(@_@)
能看看，不能看过(*_*)
------------------------------------------
'''
NUM = 10  # 基模型的数量


# AdaBoost迭代函数
def AdaBoost(weights, model):
    global xtr, ytr, xte
    model.fit(xtr, ytr)
    ypr = model.predict(xtr)

    E = np.array(ypr) != np.array(ytr)
    # 修改样本权重
    err = sum(weights * E)
    alpha = 1 / 2 * math.log((1 - err) / err)
    Z = sum(weights * np.exp(-alpha * ytr * ypr))
    weights = weights * np.exp(-alpha * ytr * ypr) / Z
    # 返回分类器权重系数，样本权重系数和模型
    return alpha, weights, model


data = []
label = []
with open('Multi-classification_data3.csv', 'r') as f:
    reader = csv.reader(f)
    n = 0
    for row in reader:
        if n == 0:
            n += 1
            continue
        r = [float(i) for i in row[0:-1]]
        data.append(r)
        label.append(row[-1])
label_name = {}
n = 0
for item in label:
    if item not in label_name:
        label_name[item] = n
        n += 1

label = [label_name[item] for item in label]

xtr, xte, ytr, yte = train_test_split(data, label, test_size=0.3, random_state=3)
xtr, xte, ytr, yte = np.array(xtr), np.array(xte), np.array(ytr), np.array(yte)

sample_weights = np.ones((NUM, len(xtr))) / len(xtr)  # 初始化权重矩阵，每个样本的权重相同
Base_model_weights = np.ones((1, NUM))  # 初始化基模型权重，每个模型权重相同

model = []
for i in range(NUM):
    model.append(svm.SVC(C=random()))

ypr = []
for i in range(NUM - 1):
    alpha, sample_weights[i + 1], model[i] = AdaBoost(sample_weights[i], model[i])
    Base_model_weights[0][i] = alpha
    ypr.append(model[i].predict(xte))

model[-1].fit(xtr, ytr)
ypr0 = model[-1].predict(xtr)
E = np.array(ypr0) != np.array(ytr)
# 修改样本权重
err = sum(sample_weights[-1] * E)
Base_model_weights[0][-1] = 1 / 2 * math.log((1 - err) / err)
ypr.append(model[-1].predict(xte))

# 投票机制
final_ypr = []
for i in range(len(ypr[0])):
    # 按权重计算第i个样本的投票结果
    y = {}
    # 按标签添加第j个基模型的权重（投票）
    for j in range(NUM):
        if ypr[j][i] in y:
            y[ypr[j][i]] += Base_model_weights[0][j]
        else:
            y[ypr[j][i]] = Base_model_weights[0][j]
    # 获取权重最大的样本作为预测值
    # print(ypr)
    y_key = []
    y_val = []
    for key, val in y.items():
        y_key.append(key)
        y_val.append(val)
    m = y_val.index(max(y_val))
    final_ypr.append(y_key[m])

A = np.array(final_ypr) == np.array(yte)
acc = sum(A) / len(yte)
print("准确率为：%f%%" % (acc * 100))


'''
---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------
'''
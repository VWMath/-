import csv
import numpy as np
import matplotlib.pyplot as plt
from random import random
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

'''
------------------------------------------
运行后会有一段报错，问题出在逻辑回归收敛精度，不影响程序正常运行，可以直接忽略
若运行绘图代码，可能会有一小段时间卡顿，属于正常现象
由于数据集特征数量较多，最后的绘图只绘制了前两个维度上的特征（mean和radius）,并非完整的分类图
因屏幕大小有限，且用处不大，最后的图像只有前三个基模型和集成学习的对比图
最后绘图的代码可以优化，但是我懒，能跑就行(-_-)
------------------------------------------
'''

NUM = 50  # 基模型数量
data = []
label = []
with open('breast_cancer.csv', 'r') as f:
    reader = csv.reader(f)
    n = 0
    for row in reader:
        if n == 0:
            n += 1
            continue
        r = [float(i) for i in row[0:-1]]
        data.append(r)
        label.append(row[-1])

label_name = {}
n = 0
for item in label:
    if item not in label_name:
        label_name[item] = n
        n += 1

label = [label_name[item] for item in label]

xtr, xte, ytr, yte = train_test_split(data, label, test_size=0.2, random_state=3)

xtr_list = [[] for i in range(NUM)]
ytr_list = [[] for i in range(NUM)]

# 分割训练集，从训练集中随机抽取百分之70的样本
for i in range(NUM):
    for j in range(len(xtr)):
        r = random()
        if r < 0.7:
            xtr_list[i].append(xtr[j])
            ytr_list[i].append(ytr[j])

# 对每个基模型进行训练并得到每个基模型的预测值
model = []
ypr_list = []
for i in range(NUM):
    model.append(LogisticRegression())
    model[i].fit(xtr_list[i], ytr_list[i])
    ypr_list.append(model[i].predict(xte))

# 根据投票法得到最终的预测值
ypr = []
for i in range(len(ypr_list[0])):
    y = []
    for j in range(len(ypr_list)):
        y.append(ypr_list[j][i])
    ypr.append(max(y))

A = np.array(ypr) == np.array(yte)
acc = sum(A) / len(yte)
print("准确率为：%f%%" % (acc * 100))

# ------------------------
# 绘制图像
A1 = np.array(ypr_list[0]) == np.array(yte)
A2 = np.array(ypr_list[1]) == np.array(yte)
A3 = np.array(ypr_list[2]) == np.array(yte)


def get_rec(err):
    ex = [item[0] for item in err]
    ey = [item[1] for item in err]
    x, y = min(ex), min(ey)
    w, h = max(ex) - x, max(ey) - y
    rect = plt.Rectangle((x, y), w, h, linewidth=2, edgecolor='g', facecolor='none')

    return rect


def draw(n, ypr, A, title):
    plt.subplot(3, 4, n + 8)
    err = []
    for i in range(len(xte)):
        if not A[i]:
            plt.scatter(xte[i][0], xte[i][1], c='r')
            err.append(xte[i])
    plt.title("error")

    plt.subplot(3, 4, n)
    for i in range(len(xte)):
        if yte[i] == 0:
            plt.scatter(xte[i][0], xte[i][1], c='b')
        else:
            plt.scatter(xte[i][0], xte[i][1], c='r')
    rect = get_rec(err)
    ax = plt.gca()
    ax.add_patch(rect)
    plt.title("test_dataset")

    plt.subplot(3, 4, n + 4)
    for i in range(len(xte)):
        if ypr[i] == 0:
            plt.scatter(xte[i][0], xte[i][1], c='b')
        else:
            plt.scatter(xte[i][0], xte[i][1], c='r')
    rect = get_rec(err)
    ax = plt.gca()
    ax.add_patch(rect)
    plt.title(title)


plt.figure(1)
for i in range(len(xtr)):
    if ytr[i] == 0:
        plt.scatter(xtr[i][0], xtr[i][1], c='b')
    else:
        plt.scatter(xtr[i][0], xtr[i][1], c='r')
plt.title("train_dataset")

plt.figure(2)
draw(1, ypr, A, 'Ypr')
draw(2, ypr_list[0], A1, 'Ypr1')
draw(3, ypr_list[1], A2, 'Ypr2')
draw(4, ypr_list[2], A3, 'Ypr3')

plt.show()


'''
---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------
'''
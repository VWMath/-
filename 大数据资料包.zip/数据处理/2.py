import csv

data = []
label = []
'''
以只读模式打开文件，写入模式为'w',追加模式为'a'，使用csv.writer写入时
记得设置newline = ''，否则会出现隔行写入的情况
共提供两种方法，根据个人喜好选择，推荐第一种，且后续均采用第一种方法
'''
# 方法一
with open('digits.csv', 'r') as f:
    csv_reader = csv.reader(f)  # 设置读取器
    n = 0  # 用于判断读取的是否为表头
    for row in csv_reader:  # 遍历文件的每一行
        '''
        表头在第一行，故第一次读取的时候直接跳过，为避免
        以后的循环接着跳过，将n加一，使之后的条件不再触发
        '''
        if n == 0:
            n += 1
            continue  # 跳到下一轮循环
        '''
        将该行的第一个到倒数第二个（即数据）从字符串转为浮点型
        并间结果赋值给r，注意切片表达式包左不包右
        '''
        r = [float(i) for i in row[0:-1]]
        data.append(r)  # 向data中添加该行（处理后为浮点型的数据）
        '''
        将标签添加到label列表中，注意row[-1]的类型是字符串，需要转化
        该数据集不能直接转为int类型（看数据集最后一列），需要转两步
        '''
        label.append(int(float(row[-1])))

'''
多行同时注释/消注快捷键
Spyder:选中要注释/取消注释的行，键盘按下ctrl+1
Pycharm:选中要注释/取消注释的行，键盘按下ctrl+/
VScode:选中要注释/取消注释的行，键盘按下ctrl+/
'''
# 方法二
# with open('digits.csv', 'r') as f:
#     csv_reader = csv.reader(f)  # 设置读取器
#     n = 0  # 用于判断读取的是否为表头
#     for row in csv_reader:  # 遍历文件的每一行
#         '''
#         将该行的第一个到倒数第二个数据，添加到data中
#         注意
#         1.切片表达式包左不包右
#         2.此时含表头，不能直接转为float或int
#         '''
#         data.append(row[0:-1])
#         label.append(row[-1])
# # 通过切片去除data，label中的表头,注意不要写成[1:-1],这样会把最后一行也去了
# data = data[1:]
# label = label[1:]
#
# # 通过for循环将data每行的数据从字符串转为浮点型
# for i in range(len(data)):
#     '''
#     以data的第i行的长度写列表推导式，对第i行的第j个依次进行类型转换，得到
#     的列表为对应的浮点型的data的第i行数据，用于更新data[i]
#     '''
#     data[i] = [float(data[i][j]) for j in range(len(data[i]))]
#
# # 对label中的每个元素进行类型转化
# label = [int(float(label[i])) for i in range(len(label))]

print("数据为：")
print(data)
print("标签为：")
print(label)



'''
---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------
'''
import csv
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression


# 绘图用，可以忽略
def get_rec(err):
    ex = [item[0] for item in err]
    ey = [item[1] for item in err]
    x, y = min(ex), min(ey)
    w, h = max(ex) - x, max(ey) - y
    rect = plt.Rectangle((x, y), w, h, linewidth=2, edgecolor='g', facecolor='none')

    return rect


data = []
label = []
with open('classification_data1.csv', 'r') as f:
    reader = csv.reader(f)
    n = 0
    for row in reader:
        if n == 0:
            n += 1
            continue
        r = [float(i) for i in row[0:-1]]
        data.append(r)
        label.append(int(float(row[-1])))

xtr, xte, ytr, yte = train_test_split(data, label, test_size=0.3, random_state=3)

model = LogisticRegression()
model.fit(xtr, ytr)
ypr = model.predict(xte)

A = np.array(ypr) == np.array(yte)
acc = sum(A) / len(yte)
print("准确率为：%f%%" % (acc * 100))

# ------------------------
# 绘制图像
plt.figure()
plt.subplot(2, 2, 1)
for i in range(len(xtr)):
    if ytr[i] == 0:
        plt.scatter(xtr[i][0], xtr[i][1], c='b')
    else:
        plt.scatter(xtr[i][0], xtr[i][1], c='r')
plt.title("train_dataset")

plt.subplot(2, 2, 2)
err = []
for i in range(len(xte)):
    if not A[i]:
        plt.scatter(xte[i][0], xte[i][1], c='r')
        err.append(xte[i])

plt.title("error")

plt.subplot(2, 2, 3)
for i in range(len(xte)):
    if yte[i] == 0:
        plt.scatter(xte[i][0], xte[i][1], c='b')
    else:
        plt.scatter(xte[i][0], xte[i][1], c='r')

rect = get_rec(err)
ax = plt.gca()
ax.add_patch(rect)

plt.title("test_dataset")

plt.subplot(2, 2, 4)
for i in range(len(xte)):
    if ypr[i] == 0:
        plt.scatter(xte[i][0], xte[i][1], c='b')
    else:
        plt.scatter(xte[i][0], xte[i][1], c='r')
plt.title("predict")
rect = get_rec(err)
ax = plt.gca()
ax.add_patch(rect)
plt.show()


'''
---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------
'''
import csv
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB

data = []
label = []
with open('digits.csv', 'r') as f:
    reader = csv.reader(f)
    n = 0
    for row in reader:
        if n == 0:
            n += 1
            continue
        r = [float(i) for i in row[0:-1]]
        data.append(r)
        label.append(int(float(row[-1])))

xtr, xte, ytr, yte = train_test_split(data, label, test_size=0.3, random_state=3)

gnb = GaussianNB()
gnb.fit(xtr, ytr)
ypr = gnb.predict(xte)

acc = sum(np.array(ypr) == np.array(yte)) / len(yte)
print("准确率为：%f%%" % (acc * 100))


'''
---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------
'''
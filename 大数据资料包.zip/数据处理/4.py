import csv

data = []
label = []
'''
以只读模式打开文件，写入模式为'w',追加模式为'a'，使用csv.writer写入时
记得设置newline = ''，否则会出现隔行写入的情况
'''
with open('wine.csv', 'r') as f:
    csv_reader = csv.reader(f)  # 设置读取器
    n = 0  # 用于判断读取的是否为表头
    for row in csv_reader:  # 遍历文件的每一行
        '''
        表头在第一行，故第一次读取的时候直接跳过，为避免
        以后的循环接着跳过，将n加一，使之后的条件不再触发
        '''
        if n == 0:
            n += 1
            continue  # 跳到下一轮循环
        '''
        将该行的第一个到倒数第二个（即数据）从字符串转为浮点型
        并间结果赋值给r，注意切片表达式包左不包右
        '''
        r = [float(i) for i in row[0:-1]]
        data.append(r)  # 向data中添加该行（处理后为浮点型的数据）
        label.append(row[-1])  # 将标签添加到label列表中

# 将标签从字符串转为0，1，2....的形式
label_dic = {}  # 创建一个空字典，用于储存每个标签对应的数字，例：键:值<->malignant:0
n = 0  # 第一个标签对应的数字
'''
迭代label，注意不是for i in range(len(label))
这里的item是label中的每一项，如malignant
'''
for item in label:
    if item not in label_dic:  # 判断条件为item不在label_dic里
        label_dic[item] = n  # 若字典中不含item，创建一个新的键值对，键为item，值为n
        n += 1  # 将n加一，因为下一次进入if语句的一定是新的标签，对应的值要改变

# 将label中的每个标签通过字典转为数字
label = [label_dic[item] for item in label]

print("数据为：")
print(data)
print("标签为：")
print(label)


'''
---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------
'''
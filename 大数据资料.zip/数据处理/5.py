import csv

'''
iris.csv大体上与第三类相同，除注释部分，其余部分均与3.py相同
故不多赘叙，直接看关键点
'''

data = []
label = []

with open('iris.csv', 'r') as f:
    csv_reader = csv.reader(f)
    for row in csv_reader:
        '''
        当该行为空列表时，直接退出
        注意，这样写只是因为老师的数据集空行只出现在最后一行
        对于一般情况，参考代码如下：
        if row != []:
            r = [float(i) for i in row[0:-1]]
            data.append(r)
            label.append(row[-1])
        '''
        if row == []:
            break
        r = [float(i) for i in row[0:-1]]
        data.append(r)
        label.append(row[-1])

label_dic = {}
n = 0
for item in label:
    if item not in label_dic:
        label_dic[item] = n
        n += 1
label = [label_dic[item] for item in label]

print("数据为：")
print(data)
print("标签为：")
print(label)


'''
---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------
'''
import numpy as np
import csv
import matplotlib.pyplot as plt

X = []
Y = []
with open('data_linear_regression1.csv', 'r') as f:
    reader = csv.reader(f)
    for row in reader:
        X.append(int(row[0]))
        Y.append(float(row[1]))

p = np.polyfit(np.array(X), np.array(Y), 1)

Ypr = np.polyval(p, X)
plt.figure()
plt.scatter(X, Y)
plt.plot(X, Ypr, 'red')
plt.show()


'''
---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------
'''
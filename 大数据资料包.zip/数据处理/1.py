import csv

data = []
label = []
'''
以只读模式打开文件，写入模式为'w',追加模式为'a'，使用csv.writer写入时
记得设置newline = ''，否则会出现隔行写入的情况
'''
with open('classification_data1.csv', 'r') as f:
    csv_reader = csv.reader(f)  # 设置读取器
    for row in csv_reader:  # 遍历文件的每一行
        '''
        将该行的第一个到倒数第二个（即数据）从字符串转为浮点型
        并间结果赋值给r，注意切片表达式包左不包右
        '''
        r = [float(i) for i in row[0:-1]]
        data.append(r)  # 向data中添加该行（处理后为浮点型的数据）
        '''
        将标签添加到label列表中，注意row[-1]的类型是字符串，需要转化
        该数据集不能直接转为int类型（看数据集最后一列），需要转两步
        '''
        label.append(int(float(row[-1])))
print("数据为：")
print(data)
print("标签为：")
print(label)


'''
---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------
'''
import csv
import numpy as np
from sklearn.model_selection import train_test_split


# 计算两个数据之间的距离
def distance(x, y):
    d = 0
    for i, j in zip(x, y):
        d += (i - j) ** 2
    d = d ** (1 / 2)
    return d


# 按距离远近获取索引
def sortDistanceIdx(data, dataset):
    idx = [i for i in range(len(dataset))]
    d = []
    for i in range(len(idx)):
        d.append(distance(data, dataset[i]))

    for i in range(len(d)):
        for j in range(len(d)):
            if d[i] < d[j]:
                p = d[i]
                d[i] = d[j]
                d[j] = p
                p = idx[i]
                idx[i] = idx[j]
                idx[j] = p
    return idx


# def init(data, label):
#     data = data
#     label = label

# 对未知数据分类
def predict(xtr, ytr, xte, k):
    label_list = []
    for item in xte:
        idx = sortDistanceIdx(item, xtr)
        labelCount = [0 for i in range(max(ytr) + 1)]
        for i in range(k):
            l = ytr[idx[i]]
            labelCount[l] += 1
        label = labelCount.index(max(labelCount))
        label_list.append(label)

    return label_list

# 对数据进行归一化
def Normalization(data):
    ma = [max(data[:][j]) for j in range(len(data[0]))]
    mi = [min(data[:][j]) for j in range(len(data[0]))]
    Ndata = []
    for i in range(len(data)):
        Ndata.append([(ma[j] - data[i][j]) / (ma[j] - mi[j]) for j in range(len(data[0]))])
    return data


# 处理数据
data = []
label = []
with open('iris.csv', 'r') as f:
    csv_reader = csv.reader(f)
    for row in csv_reader:
        r = [float(i) for i in row[0:-1]]
        data.append(r)
        label.append(row[-1])

label_dic = {}
n = 0
for item in label:
    if item not in label_dic.keys():
        label_dic[item] = n
        n += 1

label = [label_dic[item] for item in label]
data = Normalization(data)

xtr, xte, ytr, yte = train_test_split(data, label, test_size=0.3, random_state=3)

ypr = predict(xtr, ytr, xte, 5)

acc = sum(np.array(yte) == np.array(ypr)) / len(yte)
print("准确率为：%f" % (acc * 100))


'''
---------------------------------
本资料为个人免费资料，不得用于任何商业用途
作者联系方式：3240207488@qq.com
---------------------------------
'''